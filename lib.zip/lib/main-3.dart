// ignore_for_file: require_trailing_commas
// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// @dart=2.9

import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  runApp(MessagingExampleApp());
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print('Handling a background message ${message.data}');
}

class MessagingExampleApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Messaging Example App',
      theme: ThemeData.dark(),
      home: Application(),
    );
  }
}

int _messageCount = 0;

String constructFCMPayload(String token) {
  _messageCount++;
  return jsonEncode({
    'token': token,
    'data': {
      'via': 'FlutterFire Cloud Messaging!!!',
      'count': _messageCount.toString(),
    },
    'notification': {
      'title': 'Hello FlutterFire!',
      'body': 'This notification (#$_messageCount) was created via FCM!',
    },
  });
}

class Application extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _Application();
}

class _Application extends State<Application> {
  String _token;

  @override
  void initState() {
    super.initState();
    FirebaseMessaging.instance.getToken().then((value) {
      _token = value;
      print(_token);
    });
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage message) {
      if (message != null) {
        print(message);
      }
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null && !kIsWeb) {}
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print(message.data);
      print('A new onMessageOpenedApp event was published! YEEYYY');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Stack(
        children: [
          Center(
            child: SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.only(top: 100),
                width: double.infinity,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                    Text(
                      'SLAW',
                      style: TextStyle(fontSize: 60),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            height: 100,
            color: Colors.white,
          ),
        ],
      )),
    );
  }
}
