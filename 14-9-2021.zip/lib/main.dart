import 'package:firstproject1/bigList.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    print(bigList);
  }

  @override
  void dispose() {
    print('DISPOSE');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('BUILD METHOD');
    return MaterialApp(
      home: Scaffold(
        // backgroundColor: Colors.grey,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  width: double.infinity,
                  child: Text('HEADER'),
                  color: Colors.red,
                ),
              ),
              Expanded(
                flex: 3,
                child: ListView.builder(
                  itemBuilder: (_, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: Text(
                        '${index + 1} : ${bigList[index]['title']}',
                        style: TextStyle(fontSize: 20),
                      ),
                    );
                  },
                  // cacheExtent: 15,
                  // reverse: true,
                  itemCount: bigList.length,
                  scrollDirection: Axis.vertical,
                  padding: EdgeInsets.all(16),
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  width: double.infinity,
                  child: Text('FOOTER'),
                  color: Colors.green,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
